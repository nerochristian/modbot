import { create } from 'zustand';

export interface User {
  id: string;
  username: string;
  avatar: string;
  role: 'Owner' | 'Admin' | 'Moderator' | 'Viewer';
}

export interface Server {
  id: string;
  name: string;
  icon: string;
  memberCount: number;
}

interface AppState {
  user: User | null;
  servers: Server[];
  activeServerId: string | null;
  setActiveServer: (id: string) => void;
  login: (user: User) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: {
    id: '123456789',
    username: 'AdminUser',
    avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
    role: 'Owner',
  },
  servers: [
    { id: '1', name: 'Global Gaming Community', icon: 'https://cdn.discordapp.com/embed/avatars/1.png', memberCount: 15420 },
    { id: '2', name: 'Dev Support Server', icon: 'https://cdn.discordapp.com/embed/avatars/2.png', memberCount: 3200 },
    { id: '3', name: 'Private Friends', icon: 'https://cdn.discordapp.com/embed/avatars/3.png', memberCount: 45 },
  ],
  activeServerId: '1',
  setActiveServer: (id) => set({ activeServerId: id }),
  login: (user) => set({ user }),
  logout: () => set({ user: null, activeServerId: null }),
}));
