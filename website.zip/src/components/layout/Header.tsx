import { useAppStore } from '@/store/useAppStore';
import { ChevronDown, Bell, Search, LogOut } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

export function Header() {
  const { user, servers, activeServerId, setActiveServer, logout } = useAppStore();
  const [isServerMenuOpen, setIsServerMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const activeServer = servers.find((s) => s.id === activeServerId);

  return (
    <header className="h-16 bg-card-bg border-b border-cream-300 flex items-center justify-between px-6 shrink-0 sticky top-0 z-10 shadow-sm">
      <div className="flex items-center gap-4">
        {/* Server Selector */}
        <div className="relative">
          <button
            onClick={() => setIsServerMenuOpen(!isServerMenuOpen)}
            className="flex items-center gap-3 bg-app-bg hover:bg-cream-200 transition-colors px-4 py-2 rounded-xl border border-cream-300 shadow-sm"
          >
            {activeServer ? (
              <>
                <img src={activeServer.icon} alt={activeServer.name} className="w-6 h-6 rounded-full" />
                <span className="font-semibold text-slate-800">{activeServer.name}</span>
              </>
            ) : (
              <span className="font-semibold text-slate-500">Select Server</span>
            )}
            <ChevronDown className="w-4 h-4 text-slate-500" />
          </button>

          {isServerMenuOpen && (
            <div className="absolute top-full left-0 mt-2 w-64 bg-card-bg rounded-2xl shadow-soft-lg border border-cream-300 py-2 z-50">
              {servers.map((server) => (
                <button
                  key={server.id}
                  onClick={() => {
                    setActiveServer(server.id);
                    setIsServerMenuOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-2 hover:bg-app-bg transition-colors text-left",
                    activeServerId === server.id && "bg-indigo-50 text-indigo-700"
                  )}
                >
                  <img src={server.icon} alt={server.name} className="w-8 h-8 rounded-full" />
                  <div>
                    <div className="font-medium text-sm">{server.name}</div>
                    <div className="text-xs text-slate-500">{server.memberCount.toLocaleString()} members</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-6">
        {/* Search */}
        <div className="relative hidden md:block">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search settings..."
            className="pl-9 pr-4 py-2 bg-app-bg border border-cream-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all w-64"
          />
        </div>

        {/* Notifications */}
        <button className="relative p-2 text-slate-500 hover:bg-app-bg rounded-xl transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>

        {/* User Profile */}
        <div className="relative">
          <button
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
            className="flex items-center gap-3 hover:bg-app-bg p-1.5 rounded-xl transition-colors"
          >
            <div className="text-right hidden sm:block">
              <div className="text-sm font-semibold text-slate-900">{user?.username}</div>
              <div className="text-xs text-indigo-600 font-medium">{user?.role}</div>
            </div>
            <img src={user?.avatar} alt={user?.username} className="w-9 h-9 rounded-full border-2 border-white shadow-sm" />
          </button>

          {isUserMenuOpen && (
            <div className="absolute top-full right-0 mt-2 w-48 bg-card-bg rounded-2xl shadow-soft-lg border border-cream-300 py-2 z-50">
              <button
                onClick={logout}
                className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors text-left font-medium"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
