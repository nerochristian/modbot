import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Shield, Zap, Lock, ScrollText, 
  Users, Command, BarChart3, Settings, Bot, Plug
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Overview', path: '/' },
  { icon: Shield, label: 'Moderation', path: '/moderation' },
  { icon: Zap, label: 'Automod', path: '/automod' },
  { icon: Lock, label: 'Anti-Raid', path: '/anti-raid' },
  { icon: ScrollText, label: 'Logging', path: '/logging' },
  { icon: Users, label: 'Roles & Perms', path: '/roles' },
  { icon: Command, label: 'Commands', path: '/commands' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
  { icon: Plug, label: 'Integrations', path: '/integrations' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export function Sidebar() {
  return (
    <aside className="w-64 bg-sidebar-bg border-r border-cream-300 flex flex-col h-full shrink-0">
      <div className="h-16 flex items-center px-6 border-b border-cream-300">
        <div className="flex items-center gap-3 text-indigo-600">
          <Bot className="w-8 h-8" />
          <span className="font-display font-bold text-xl text-slate-800 tracking-tight">modbot</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
        <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4 px-2">
          Configuration
        </div>
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium transition-all duration-200",
              isActive 
                ? "bg-white text-indigo-600 shadow-sm" 
                : "text-slate-600 hover:bg-white/50 hover:text-slate-900"
            )}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </NavLink>
        ))}
      </div>
    </aside>
  );
}
