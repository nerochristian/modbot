/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { Overview } from './pages/Overview';
import { Moderation } from './pages/Moderation';
import { Automod } from './pages/Automod';
import { AntiRaid } from './pages/AntiRaid';
import { Logging } from './pages/Logging';
import { Roles } from './pages/Roles';
import { Commands } from './pages/Commands';
import { Analytics } from './pages/Analytics';
import { Integrations } from './pages/Integrations';
import { Settings } from './pages/Settings';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<DashboardLayout />}>
          <Route index element={<Overview />} />
          <Route path="moderation" element={<Moderation />} />
          <Route path="automod" element={<Automod />} />
          <Route path="anti-raid" element={<AntiRaid />} />
          <Route path="logging" element={<Logging />} />
          <Route path="roles" element={<Roles />} />
          <Route path="commands" element={<Commands />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="integrations" element={<Integrations />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

