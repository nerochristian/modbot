import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Users, Shield, UserCheck, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export function Roles() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Roles & Permissions</h1>
          <p className="text-gray-500 mt-2 text-lg">Map Discord roles to bot permissions and manage dashboard access.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                <Shield className="w-5 h-5" />
              </div>
              <CardTitle>Bot Permissions</CardTitle>
            </div>
            <CardDescription>Assign bot roles to Discord roles.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {[
              { role: 'Administrator', discordRole: '@Admin', desc: 'Full access to all bot commands and dashboard.' },
              { role: 'Moderator', discordRole: '@Moderator', desc: 'Can use moderation commands (ban, kick, warn).' },
              { role: 'Helper', discordRole: '@Helper', desc: 'Can use basic commands (mute, warn).' },
            ].map((mapping, i) => (
              <div key={i} className="space-y-3 p-4 bg-cream-50 rounded-2xl border border-cream-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">{mapping.role}</h4>
                    <p className="text-xs text-gray-500">{mapping.desc}</p>
                  </div>
                  <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold border border-indigo-200">
                    {mapping.discordRole}
                  </span>
                </div>
                <select className="w-full bg-white border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all">
                  <option>{mapping.discordRole}</option>
                  <option>@Owner</option>
                  <option>@Admin</option>
                  <option>@Moderator</option>
                  <option>@Helper</option>
                  <option>@everyone</option>
                </select>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                <Settings2 className="w-5 h-5" />
              </div>
              <CardTitle>Dashboard Access</CardTitle>
            </div>
            <CardDescription>Control who can view and edit settings on this dashboard.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { perm: 'View Dashboard', roles: ['@Admin', '@Moderator'] },
              { perm: 'Edit Moderation Settings', roles: ['@Admin'] },
              { perm: 'Edit Automod Rules', roles: ['@Admin'] },
              { perm: 'Manage Roles', roles: ['@Owner'] },
              { perm: 'View Analytics', roles: ['@Admin', '@Moderator'] },
            ].map((access, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
                <span className="text-sm font-medium text-gray-700">{access.perm}</span>
                <div className="flex gap-2">
                  {access.roles.map((role, j) => (
                    <span key={j} className="px-2.5 py-1 bg-white border border-cream-300 rounded-lg text-xs font-medium text-gray-600">
                      {role}
                    </span>
                  ))}
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-gray-400 hover:text-indigo-600">
                    +
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
