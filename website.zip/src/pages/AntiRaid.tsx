import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Button } from '@/components/ui/Button';
import { ShieldAlert, Lock, UserPlus, ShieldCheck, AlertOctagon } from 'lucide-react';

export function AntiRaid() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Anti-Raid Control</h1>
          <p className="text-gray-500 mt-2 text-lg">Protect your server from coordinated attacks and bot raids.</p>
        </div>
        <Button variant="danger" className="gap-2 shadow-soft-lg animate-pulse hover:animate-none">
          <AlertOctagon className="w-5 h-5" />
          PANIC MODE
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-red-200">
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-red-50 text-red-600 rounded-xl">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <CardTitle>Join Rate Detection</CardTitle>
            </div>
            <CardDescription>Automatically trigger defenses if too many users join at once.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
              <div>
                <h4 className="font-semibold text-gray-900">Enable Detection</h4>
                <p className="text-sm text-gray-500">Monitor join velocity.</p>
              </div>
              <Switch checked={true} />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700">Users Joined</label>
                  <input type="number" defaultValue={10} className="w-full mt-1 bg-cream-50 border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all" />
                </div>
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700">Time Window (Seconds)</label>
                  <input type="number" defaultValue={5} className="w-full mt-1 bg-cream-50 border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                <Lock className="w-5 h-5" />
              </div>
              <CardTitle>Auto-Defenses</CardTitle>
            </div>
            <CardDescription>Actions to take when a raid is detected.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { name: 'Lockdown Server', desc: 'Prevents new users from seeing channels.', icon: Lock, active: true },
              { name: 'Enable Verification', desc: 'Requires users to complete a CAPTCHA.', icon: ShieldCheck, active: true },
              { name: 'Auto-Kick New Accounts', desc: 'Kicks accounts younger than 24 hours.', icon: UserPlus, active: false },
            ].map((def, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-white rounded-lg border border-cream-200 text-gray-500">
                    <def.icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm">{def.name}</h4>
                    <p className="text-xs text-gray-500">{def.desc}</p>
                  </div>
                </div>
                <Switch checked={def.active} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
