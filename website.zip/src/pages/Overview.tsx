import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { ShieldAlert, Users, MessageSquare, Activity, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useAppStore } from '@/store/useAppStore';

export function Overview() {
  const { servers, activeServerId } = useAppStore();
  const activeServer = servers.find(s => s.id === activeServerId);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Overview</h1>
        <p className="text-gray-500 mt-2 text-lg">Server health and moderation summary for {activeServer?.name}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Active Warnings" 
          value="24" 
          trend="+12% this week" 
          icon={AlertTriangle} 
          color="text-amber-500" 
          bg="bg-amber-50" 
        />
        <StatCard 
          title="Messages Filtered" 
          value="1,432" 
          trend="-5% this week" 
          icon={ShieldCheck} 
          color="text-indigo-500" 
          bg="bg-indigo-50" 
        />
        <StatCard 
          title="Users Banned" 
          value="7" 
          trend="Same as last week" 
          icon={ShieldAlert} 
          color="text-red-500" 
          bg="bg-red-50" 
        />
        <StatCard 
          title="Active Members" 
          value={activeServer?.memberCount.toLocaleString() || "0"} 
          trend="+124 this week" 
          icon={Users} 
          color="text-emerald-500" 
          bg="bg-emerald-50" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest moderation actions taken by the bot and staff.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {[
                { action: 'User Banned', user: 'spammer#1234', reason: 'Phishing links', time: '10 mins ago', type: 'danger' },
                { action: 'Message Deleted', user: 'angry_user', reason: 'Profanity filter', time: '1 hour ago', type: 'warning' },
                { action: 'User Warned', user: 'rulebreaker', reason: 'Spamming chat', time: '2 hours ago', type: 'warning' },
                { action: 'Automod Rule Updated', user: 'AdminUser', reason: 'Added new regex pattern', time: '5 hours ago', type: 'info' },
              ].map((log, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className={`w-2 h-2 mt-2 rounded-full shrink-0 ${
                    log.type === 'danger' ? 'bg-red-500' : 
                    log.type === 'warning' ? 'bg-amber-500' : 'bg-indigo-500'
                  }`} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {log.action} <span className="text-gray-500 font-normal">({log.user})</span>
                    </p>
                    <p className="text-sm text-gray-500 mt-0.5">{log.reason}</p>
                  </div>
                  <div className="ml-auto text-xs text-gray-400">{log.time}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Current health of bot modules.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: 'Automod Engine', status: 'Operational', color: 'text-emerald-600', bg: 'bg-emerald-100' },
                { name: 'Anti-Raid Protection', status: 'Active', color: 'text-emerald-600', bg: 'bg-emerald-100' },
                { name: 'Logging Service', status: 'Operational', color: 'text-emerald-600', bg: 'bg-emerald-100' },
                { name: 'Discord API', status: 'Degraded', color: 'text-amber-600', bg: 'bg-amber-100' },
              ].map((sys, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-cream-50 border border-cream-200">
                  <div className="flex items-center gap-3">
                    <Activity className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium text-gray-700">{sys.name}</span>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${sys.bg} ${sys.color}`}>
                    {sys.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, trend, icon: Icon, color, bg }: any) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`p-3 rounded-2xl ${bg} ${color}`}>
            <Icon className="w-6 h-6" />
          </div>
          <span className="text-sm font-medium text-gray-500">{trend}</span>
        </div>
        <div className="mt-4">
          <h3 className="text-3xl font-display font-bold text-gray-900">{value}</h3>
          <p className="text-sm text-gray-500 mt-1 font-medium">{title}</p>
        </div>
      </CardContent>
    </Card>
  );
}
