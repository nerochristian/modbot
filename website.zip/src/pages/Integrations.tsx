import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Key, Webhook, Link2, Plus, Trash2 } from 'lucide-react';

export function Integrations() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-slate-900 tracking-tight">Integrations</h1>
          <p className="text-slate-500 mt-2 text-lg">Manage webhooks, external services, and API keys.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Webhook className="w-5 h-5" />
                </div>
                <CardTitle>Webhooks</CardTitle>
              </div>
              <Button size="sm" variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Add
              </Button>
            </div>
            <CardDescription>Send bot events to external URLs.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { name: 'Mod Logs to Zapier', url: 'https://hooks.zapier.com/...', active: true },
              { name: 'Analytics Sync', url: 'https://api.example.com/...', active: false },
            ].map((hook, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
                <div>
                  <h4 className="font-semibold text-slate-900 text-sm">{hook.name}</h4>
                  <p className="text-xs text-slate-500 font-mono mt-1 truncate w-48">{hook.url}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 text-[10px] font-bold uppercase rounded-md ${hook.active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    {hook.active ? 'Active' : 'Paused'}
                  </span>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-500 hover:bg-red-50">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                  <Key className="w-5 h-5" />
                </div>
                <CardTitle>API Keys</CardTitle>
              </div>
              <Button size="sm" variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Generate
              </Button>
            </div>
            <CardDescription>Access the modbot API programmatically.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Primary Key</label>
              <div className="flex gap-2">
                <input 
                  type="password" 
                  value="sk_live_1234567890abcdef" 
                  readOnly 
                  className="flex-1 bg-cream-50 border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all" 
                />
                <Button variant="outline">Copy</Button>
              </div>
              <p className="text-xs text-slate-500">Keep this key secret. It provides full access to your server's modbot data.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
