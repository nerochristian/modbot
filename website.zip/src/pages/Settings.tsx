import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Button } from '@/components/ui/Button';
import { Settings as SettingsIcon, Key, Database, RefreshCw, AlertTriangle, Download, Upload } from 'lucide-react';

export function Settings() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-slate-900 tracking-tight">Settings</h1>
          <p className="text-slate-500 mt-2 text-lg">Manage bot behavior, server profile, backups, and dangerous actions.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                <Key className="w-5 h-5" />
              </div>
              <CardTitle>API & Webhooks</CardTitle>
            </div>
            <CardDescription>Manage external integrations and API access.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <label className="text-sm font-medium text-gray-700">API Key</label>
              <div className="flex gap-2">
                <input 
                  type="password" 
                  value="sk_live_1234567890abcdef" 
                  readOnly 
                  className="flex-1 bg-cream-50 border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all" 
                />
                <Button variant="outline">Regenerate</Button>
              </div>
              <p className="text-xs text-gray-500">Keep this key secret. It provides full access to your server's modbot data.</p>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-medium text-gray-700">Webhook URL (Events)</label>
              <input 
                type="url" 
                placeholder="https://..." 
                className="w-full bg-cream-50 border border-cream-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all" 
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                <Database className="w-5 h-5" />
              </div>
              <CardTitle>Data Management</CardTitle>
            </div>
            <CardDescription>Backup and restore your server configuration.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
              <div>
                <h4 className="font-semibold text-gray-900 text-sm">Auto-Backups</h4>
                <p className="text-xs text-gray-500">Daily configuration backups.</p>
              </div>
              <Switch checked={true} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="gap-2">
                <Download className="w-4 h-4" />
                Export Config
              </Button>
              <Button variant="outline" className="gap-2">
                <Upload className="w-4 h-4" />
                Import Config
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-red-200">
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-red-50 text-red-600 rounded-xl">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <CardTitle className="text-red-600">Danger Zone</CardTitle>
            </div>
            <CardDescription>Irreversible actions that affect your server's data.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-2xl border border-red-200">
              <div>
                <h4 className="font-semibold text-red-900">Wipe Moderation History</h4>
                <p className="text-sm text-red-700">Deletes all warnings, kicks, and bans from the bot's database.</p>
              </div>
              <Button variant="danger">Wipe Data</Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-red-50 rounded-2xl border border-red-200">
              <div>
                <h4 className="font-semibold text-red-900">Reset Configuration</h4>
                <p className="text-sm text-red-700">Resets all settings to their default values.</p>
              </div>
              <Button variant="danger">Reset Settings</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
