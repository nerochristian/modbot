import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { ScrollText, Settings, Download, Search } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export function Logging() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Logging & Audit</h1>
          <p className="text-gray-500 mt-2 text-lg">Configure what events are logged and where they are sent.</p>
        </div>
        <Button variant="outline" className="gap-2 shadow-sm">
          <Download className="w-4 h-4" />
          Export Logs
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                  <ScrollText className="w-5 h-5" />
                </div>
                <CardTitle>Event Categories</CardTitle>
              </div>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search events..."
                  className="pl-9 pr-4 py-2 bg-cream-50 border border-cream-300 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all w-64"
                />
              </div>
            </div>
            <CardDescription>Select which events should be recorded in your server logs.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {[
              { category: 'Message Events', events: ['Message Deleted', 'Message Edited', 'Bulk Delete'] },
              { category: 'Member Events', events: ['Member Joined', 'Member Left', 'Role Updated', 'Nickname Changed'] },
              { category: 'Moderation Events', events: ['User Banned', 'User Kicked', 'User Warned', 'User Timed Out'] },
              { category: 'Server Events', events: ['Channel Created', 'Channel Deleted', 'Server Settings Updated'] },
            ].map((section, i) => (
              <div key={i} className="space-y-3">
                <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">{section.category}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {section.events.map((event, j) => (
                    <div key={j} className="flex items-center justify-between p-3 bg-cream-50 rounded-xl border border-cream-200 hover:border-indigo-200 transition-colors">
                      <span className="text-sm font-medium text-gray-700">{event}</span>
                      <Switch checked={true} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                <Settings className="w-5 h-5" />
              </div>
              <CardTitle>Log Channels</CardTitle>
            </div>
            <CardDescription>Route logs to specific channels.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { type: 'Moderation Logs', channel: '#mod-logs' },
              { type: 'Message Logs', channel: '#message-logs' },
              { type: 'Join/Leave Logs', channel: '#join-leave' },
              { type: 'Server Logs', channel: '#server-logs' },
            ].map((route, i) => (
              <div key={i} className="space-y-2">
                <label className="text-sm font-medium text-gray-700">{route.type}</label>
                <select className="w-full bg-cream-50 border border-cream-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all">
                  <option>{route.channel}</option>
                  <option>#general</option>
                  <option>#bot-commands</option>
                </select>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
