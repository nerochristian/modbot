import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Command, Plus, Settings2, Trash2, Edit3, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export function Commands() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Custom Commands</h1>
          <p className="text-gray-500 mt-2 text-lg">Create and manage custom slash commands for your server.</p>
        </div>
        <Button className="gap-2 shadow-soft-lg">
          <Plus className="w-5 h-5" />
          Create Command
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {[
          { name: '/rules', desc: 'Displays server rules in an embed.', active: true, type: 'Embed', uses: 124 },
          { name: '/socials', desc: 'Links to our social media accounts.', active: true, type: 'Text', uses: 56 },
          { name: '/apply', desc: 'Sends a button to open a staff application ticket.', active: false, type: 'Interactive', uses: 0 },
        ].map((cmd, i) => (
          <Card key={i} className="group hover:border-indigo-200 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                    <Command className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-display font-semibold text-gray-900">{cmd.name}</h3>
                    <p className="text-gray-500 mt-1">{cmd.desc}</p>
                    
                    <div className="flex items-center gap-4 mt-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cream-100 text-xs font-semibold text-gray-600 border border-cream-200">
                        <MessageSquare className="w-3.5 h-3.5" />
                        {cmd.type} Response
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cream-100 text-xs font-semibold text-gray-600 border border-cream-200">
                        {cmd.uses} Uses
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-4 py-2 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-sm font-medium text-gray-600 mr-2">Status</span>
                    <Switch checked={cmd.active} />
                  </div>
                  <Button variant="outline" size="sm" className="h-10 w-10 p-0 text-gray-500 hover:text-indigo-600">
                    <Edit3 className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="h-10 w-10 p-0 text-red-500 hover:bg-red-50 hover:border-red-200">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
