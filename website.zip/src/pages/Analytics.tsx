import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { BarChart3, TrendingUp, Users, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const data = [
  { name: 'Mon', warnings: 4, bans: 1, kicks: 2 },
  { name: 'Tue', warnings: 7, bans: 0, kicks: 1 },
  { name: 'Wed', warnings: 2, bans: 0, kicks: 0 },
  { name: 'Thu', warnings: 12, bans: 3, kicks: 5 },
  { name: 'Fri', warnings: 5, bans: 1, kicks: 1 },
  { name: 'Sat', warnings: 15, bans: 2, kicks: 4 },
  { name: 'Sun', warnings: 8, bans: 0, kicks: 2 },
];

export function Analytics() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Analytics</h1>
        <p className="text-gray-500 mt-2 text-lg">Track moderation trends and server growth.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Total Actions" value="1,245" trend="+15% this week" icon={Activity} color="text-indigo-500" bg="bg-indigo-50" />
        <StatCard title="New Members" value="342" trend="+5% this week" icon={Users} color="text-emerald-500" bg="bg-emerald-50" />
        <StatCard title="Messages Filtered" value="8,901" trend="-2% this week" icon={TrendingUp} color="text-amber-500" bg="bg-amber-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Moderation Activity (7 Days)</CardTitle>
            <CardDescription>Warnings, bans, and kicks issued over the last week.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorWarnings" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e8e8e5" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} dx={-10} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: '1px solid #e8e8e5', boxShadow: '0 10px 40px -10px rgba(0,0,0,0.04)' }}
                    itemStyle={{ color: '#1f2937', fontWeight: 500 }}
                  />
                  <Area type="monotone" dataKey="warnings" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorWarnings)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Punishment Breakdown</CardTitle>
            <CardDescription>Types of punishments issued this week.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e8e8e5" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} dx={-10} />
                  <Tooltip 
                    cursor={{ fill: '#f4f4f2' }}
                    contentStyle={{ borderRadius: '1rem', border: '1px solid #e8e8e5', boxShadow: '0 10px 40px -10px rgba(0,0,0,0.04)' }}
                  />
                  <Bar dataKey="warnings" fill="#6366f1" radius={[4, 4, 0, 0]} stackId="a" />
                  <Bar dataKey="kicks" fill="#f59e0b" radius={[0, 0, 0, 0]} stackId="a" />
                  <Bar dataKey="bans" fill="#ef4444" radius={[4, 4, 0, 0]} stackId="a" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, trend, icon: Icon, color, bg }: any) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`p-3 rounded-2xl ${bg} ${color}`}>
            <Icon className="w-6 h-6" />
          </div>
          <span className="text-sm font-medium text-gray-500">{trend}</span>
        </div>
        <div className="mt-4">
          <h3 className="text-3xl font-display font-bold text-gray-900">{value}</h3>
          <p className="text-sm text-gray-500 mt-1 font-medium">{title}</p>
        </div>
      </CardContent>
    </Card>
  );
}
