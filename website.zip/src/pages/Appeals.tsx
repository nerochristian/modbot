import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Button } from '@/components/ui/Button';
import { Gavel, CheckCircle2, XCircle, Clock, ExternalLink } from 'lucide-react';

export function Appeals() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Appeals System</h1>
          <p className="text-gray-500 mt-2 text-lg">Manage ban appeals and configure the appeal form.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Pending Appeals</CardTitle>
              <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-lg text-xs font-semibold border border-amber-200">
                3 Pending
              </span>
            </div>
            <CardDescription>Review and manage user appeals.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { user: 'notabot#999', reason: 'Banned for spamming', date: '2 hours ago', status: 'pending' },
              { user: 'innocent_guy', reason: 'Banned for NSFW content', date: '5 hours ago', status: 'pending' },
              { user: 'mistake_ban', reason: 'Banned for phishing link', date: '1 day ago', status: 'pending' },
            ].map((appeal, i) => (
              <div key={i} className="flex items-start justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200 hover:border-indigo-200 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                    {appeal.user.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{appeal.user}</h4>
                    <p className="text-sm text-gray-500 mt-0.5">{appeal.reason}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-xs text-gray-400">{appeal.date}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 border-emerald-200">
                    <CheckCircle2 className="w-4 h-4 mr-1.5" />
                    Approve
                  </Button>
                  <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200">
                    <XCircle className="w-4 h-4 mr-1.5" />
                    Deny
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                <Gavel className="w-5 h-5" />
              </div>
              <CardTitle>Settings</CardTitle>
            </div>
            <CardDescription>Configure the appeals portal.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-cream-50 rounded-2xl border border-cream-200">
              <div>
                <h4 className="font-semibold text-gray-900 text-sm">Accept Appeals</h4>
                <p className="text-xs text-gray-500">Allow users to submit appeals.</p>
              </div>
              <Switch checked={true} />
            </div>
            
            <div className="space-y-3">
              <label className="text-sm font-medium text-gray-700">Appeal Cooldown</label>
              <select className="w-full bg-cream-50 border border-cream-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all">
                <option>30 Days</option>
                <option>60 Days</option>
                <option>90 Days</option>
                <option>Never (One-time)</option>
              </select>
            </div>

            <Button className="w-full gap-2">
              <ExternalLink className="w-4 h-4" />
              View Appeal Portal
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
