import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Switch } from '@/components/ui/Switch';
import { Button } from '@/components/ui/Button';
import { Zap, Plus, Settings2, Trash2, Edit3, ShieldAlert } from 'lucide-react';

export function Automod() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold text-gray-900 tracking-tight">Automod Builder</h1>
          <p className="text-gray-500 mt-2 text-lg">Create advanced rules to automatically filter messages and punish users.</p>
        </div>
        <Button className="gap-2 shadow-soft-lg">
          <Plus className="w-5 h-5" />
          Create Rule
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {[
          { name: 'Anti-Phishing Links', desc: 'Blocks known malicious domains and warns the user.', active: true, conditions: 2, actions: 3, type: 'danger' },
          { name: 'Profanity Filter', desc: 'Deletes messages containing severe profanity.', active: true, conditions: 1, actions: 1, type: 'warning' },
          { name: 'Spam Prevention', desc: 'Mutes users sending more than 5 messages in 3 seconds.', active: false, conditions: 3, actions: 2, type: 'info' },
        ].map((rule, i) => (
          <Card key={i} className="group hover:border-indigo-200 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-2xl ${
                    rule.type === 'danger' ? 'bg-red-50 text-red-600' :
                    rule.type === 'warning' ? 'bg-amber-50 text-amber-600' :
                    'bg-indigo-50 text-indigo-600'
                  }`}>
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-display font-semibold text-gray-900">{rule.name}</h3>
                    <p className="text-gray-500 mt-1">{rule.desc}</p>
                    
                    <div className="flex items-center gap-4 mt-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cream-100 text-xs font-semibold text-gray-600 border border-cream-200">
                        <Settings2 className="w-3.5 h-3.5" />
                        {rule.conditions} Conditions
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cream-100 text-xs font-semibold text-gray-600 border border-cream-200">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        {rule.actions} Actions
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-4 py-2 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-sm font-medium text-gray-600 mr-2">Status</span>
                    <Switch checked={rule.active} />
                  </div>
                  <Button variant="outline" size="sm" className="h-10 w-10 p-0 text-gray-500 hover:text-indigo-600">
                    <Edit3 className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="h-10 w-10 p-0 text-red-500 hover:bg-red-50 hover:border-red-200">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
